Summary: Merck

Select Usr_Actn_CD, Channel, Sub_Channel,Count(*) Counts 
from DWMedProStaging.merck.tbstageresponse(nolock) where startdate='20200301' and enddate='20200315' and Druglistmatchkey='4693'
group by Usr_Actn_CD,Channel,Sub_Channel


Select Tactic_ID,Cmpgn_ID,alt_job_id, prod_id, wave_id, vndr_job_id, Broadcastname, Count(*) Counts
from DWMedProStaging.merck.tbstageresponse(nolock)
 where startdate='20200301' and enddate='20200315' and Druglistmatchkey='4693'
 group by Tactic_ID,Cmpgn_ID,alt_job_id, prod_id, wave_id, vndr_job_id, Broadcastname